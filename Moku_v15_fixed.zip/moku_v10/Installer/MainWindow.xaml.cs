using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;
using Point = System.Windows.Point;

namespace MokuInstaller;

public partial class MainWindow : Window
{
    bool _en, _installing, _done;
    int _page;
    FrameworkElement? _anchor;
    DispatcherTimer? _hop;

    // глаза
    double _ex, _ey, _vx, _vy, _tx, _ty, _gx, _gy, _gtx, _gty, _blinkT = -1;
    bool _eyesInit;
    DateTime _last = DateTime.Now, _nextBlink = DateTime.Now.AddSeconds(2.5), _nextGlance = DateTime.Now, _lastMove = DateTime.MinValue;
    readonly Random _rng = new();

    string T(string ru, string en) => _en ? en : ru;

    public MainWindow()
    {
        InitializeComponent();
        var wa = SystemParameters.WorkArea;
        double k = Math.Min(1.0, Math.Min(wa.Width * 0.92 / 600, wa.Height * 0.92 / 440));
        Width = 600 * k; Height = 440 * k;   // окно всегда целиком помещается на экран
        FolderBox.Text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "Moku");
        _en = System.Globalization.CultureInfo.CurrentUICulture.TwoLetterISOLanguageName != "ru";
        CompositionTarget.Rendering += Frame;
        Closed += (_, _) => CompositionTarget.Rendering -= Frame;
        Refresh();
        SetAnchor(Step0);
    }

    // ---------- тексты и состояние ----------
    void Refresh()
    {
        Title = T("Установка Moku", "Moku Setup");
        var names = new[] { T("Лицензия", "License"), T("Папка", "Location"), T("Установка", "Install"), T("Готово", "Done") };
        var steps = new[] { Step0, Step1, Step2, Step3 };
        for (int i = 0; i < 4; i++)
        {
            steps[i].Text = (i < _page || _done ? "✓  " : "") + names[i];
            steps[i].Foreground = new SolidColorBrush(i == _page && !_done ? Color.FromRgb(247, 248, 252) : i < _page || _done ? Color.FromRgb(140, 146, 160) : Color.FromRgb(90, 96, 110));
            steps[i].FontWeight = i == _page && !_done ? FontWeights.SemiBold : FontWeights.Normal;
        }
        Page0.Visibility = _page == 0 ? Visibility.Visible : Visibility.Collapsed;
        Page1.Visibility = _page == 1 ? Visibility.Visible : Visibility.Collapsed;
        Page2.Visibility = _page == 2 ? Visibility.Visible : Visibility.Collapsed;
        Page3.Visibility = _page == 3 ? Visibility.Visible : Visibility.Collapsed;
        RuButton.Opacity = _en ? .5 : 1; EnButton.Opacity = _en ? 1 : .5;
        BackButton.Content = T("← Назад", "← Back");
        BackButton.Visibility = _page == 1 ? Visibility.Visible : Visibility.Hidden;
        LicenseBox.Text = T(
            "Moku — бесплатная программа «как есть», без гарантий.\r\n\r\n1. Moku работает локально и не требует аккаунта. История буфера обмена и настройки хранятся только на этом компьютере.\r\n2. Для погоды приложение может обращаться к сервису прогноза, для медиа — к системным данным Windows.\r\n3. Вы можете пользоваться, копировать и удалять Moku свободно. Автор не отвечает за возможный ущерб от использования.\r\n4. Moku можно удалить в любой момент: закройте его в трее и удалите папку установки.",
            "Moku is a free program provided \"as is\", without warranty.\r\n\r\n1. Moku works locally and needs no account. Clipboard history and settings stay on this computer.\r\n2. The app may contact a weather service for the forecast and uses Windows system data for media.\r\n3. You may use, copy and remove Moku freely. The author is not liable for any damage from its use.\r\n4. To uninstall, exit Moku from the tray and delete the install folder.");
        AgreeCheck.Content = T("Я принимаю условия лицензии", "I accept the license terms");
        FolderLabel.Text = T("ПАПКА УСТАНОВКИ", "INSTALL LOCATION");
        BrowseButton.Content = T("Выбрать", "Choose");
        DesktopCheck.Content = T("Ярлык на рабочем столе", "Desktop shortcut");
        AutoCheck.Content = T("Запускать вместе с Windows", "Start with Windows");
        LaunchCheck.Content = T("Запустить Moku сейчас", "Launch Moku now");
        string hint = "";
        switch (_page)
        {
            case 0: Headline.Text = T("Лицензия", "License"); hint = AgreeCheck.IsChecked == true ? T("Отлично. Жми «Далее».", "Great. Press Next.") : T("Сначала согласись с условиями, потом пойдём дальше.", "First accept the terms, then we'll move on."); break;
            case 1: Headline.Text = T("Куда поставим?", "Where to install?"); hint = string.IsNullOrWhiteSpace(FolderBox.Text) ? T("Выбери папку установки.", "Choose an install folder.") : T("Можно оставить как есть и жать «Установить».", "Keep the default and press Install if you like."); break;
            case 2: Headline.Text = T("Устанавливаю…", "Installing…"); hint = T("Не закрывай окно, это быстро.", "Keep this window open, it's quick."); break;
            default: Headline.Text = T("Готово!", "All set!"); hint = T("Остров появится сверху экрана, а значок — в трее (возможно, за стрелкой «^»).", "The island appears at the top of the screen; the icon is in the tray (maybe behind the \"^\" arrow)."); break;
        }
        HintText.Text = hint;
        NextButton.Content = _page switch { 0 => T("Далее →", "Next →"), 1 => T("Установить", "Install"), 2 => T("Подожди…", "Please wait…"), _ => T("Готово", "Finish") };
        NextButton.IsEnabled = _page switch { 0 => AgreeCheck.IsChecked == true, 1 => !string.IsNullOrWhiteSpace(FolderBox.Text), 2 => false, _ => true };
    }

    void GoPage(int p)
    {
        _page = p; Refresh();
        SetAnchor(new[] { Step0, Step1, Step2, Step3 }[p]);
        Hop(900, () => SetAnchor(_page switch
        {
            0 => AgreeCheck.IsChecked == true ? NextButton : AgreeCheck,
            1 => FolderBox,
            2 => Progress,
            _ => NextButton
        }));
    }

    void Hop(int ms, Action a)
    {
        _hop?.Stop();
        _hop = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(ms) };
        _hop.Tick += (_, _) => { _hop!.Stop(); a(); };
        _hop.Start();
    }

    void SetAnchor(FrameworkElement el) => _anchor = el;

    // ---------- глазки ----------
    void Frame(object? s, EventArgs e)
    {
        var now = DateTime.Now;
        double dt = Math.Clamp((now - _last).TotalSeconds, 0.001, 0.05); _last = now;
        if (_anchor != null && _anchor.IsVisible && _anchor.IsLoaded)
        {
            try
            {
                var p = _anchor.TransformToVisual(EyeLayer).Transform(new Point(0, _anchor.ActualHeight / 2));
                _tx = p.X - 30; _ty = p.Y - 8;
                if (!_eyesInit) { _ex = _tx; _ey = _ty; _eyesInit = true; }
            }
            catch (InvalidOperationException) { }
        }
        if (!_eyesInit) return;
        // мягкая пружина: плавный перелёт без рывков
        const double k = 95, c = 17.5;
        _vx += ((_tx - _ex) * k - _vx * c) * dt; _vy += ((_ty - _ey) * k - _vy * c) * dt;
        _ex += _vx * dt; _ey += _vy * dt;
        // взгляд: за курсором, а если он стоит — сам поглядывает по сторонам (не спит)
        if ((now - _lastMove).TotalSeconds < 2.5)
        {
            var m = Mouse.GetPosition(EyeLayer);
            _gtx = Math.Clamp((m.X - _ex) / 60, -2.6, 2.6); _gty = Math.Clamp((m.Y - _ey) / 60, -1.6, 1.6);
        }
        else if (now >= _nextGlance)
        {
            _gtx = (_rng.NextDouble() * 2 - 1) * 2.4; _gty = (_rng.NextDouble() * 2 - 1) * 1.3;
            _nextGlance = now.AddSeconds(1.3 + _rng.NextDouble() * 2.7);
        }
        double f = 1 - Math.Exp(-7 * dt);
        _gx += (_gtx - _gx) * f; _gy += (_gty - _gy) * f;
        Canvas.SetLeft(Eyes, _ex + _gx); Canvas.SetTop(Eyes, _ey + _gy);
        double speed = Math.Sqrt(_vx * _vx + _vy * _vy);
        double open = 1 + Math.Min(0.12, speed / 1800);
        double blink = 1;
        if (_blinkT >= 0)
        {
            _blinkT += dt; double ph = _blinkT / 0.18;
            if (ph >= 1) { _blinkT = -1; _nextBlink = now.AddSeconds(_rng.NextDouble() < 0.2 ? 0.3 : 2.5 + _rng.NextDouble() * 3.5); }
            else blink = 1 - 0.92 * Math.Sin(Math.PI * ph);
        }
        else if (now >= _nextBlink) _blinkT = 0;
        EyeLScale.ScaleY = EyeRScale.ScaleY = Math.Max(0.07, open * blink);
    }

    void Window_MouseMove(object sender, System.Windows.Input.MouseEventArgs e) => _lastMove = DateTime.Now;
    void Window_Loaded(object sender, RoutedEventArgs e) { Activate(); Hop(700, () => SetAnchor(AgreeCheck)); }
    void Drag_Down(object sender, MouseButtonEventArgs e) { if (e.ButtonState == MouseButtonState.Pressed) DragMove(); }

    // ---------- события ----------
    void Ru_Click(object s, RoutedEventArgs e) { _en = false; Refresh(); }
    void En_Click(object s, RoutedEventArgs e) { _en = true; Refresh(); }
    void Close_Click(object s, RoutedEventArgs e) { if (!_installing) Close(); }
    void Agree_Changed(object s, RoutedEventArgs e) { Refresh(); SetAnchor(AgreeCheck.IsChecked == true ? NextButton : AgreeCheck); }
    void Folder_Changed(object s, TextChangedEventArgs e) { if (IsLoaded) { Refresh(); Hop(1200, () => SetAnchor(NextButton)); } }
    void Back_Click(object s, RoutedEventArgs e) { if (_page == 1 && !_installing) GoPage(0); }

    void Browse_Click(object s, RoutedEventArgs e)
    {
        var d = new OpenFolderDialog { Title = T("Выбери папку для Moku", "Choose Moku folder"), InitialDirectory = Directory.Exists(FolderBox.Text) ? FolderBox.Text : null };
        if (d.ShowDialog(this) == true) { FolderBox.Text = d.FolderName; SetAnchor(NextButton); }
    }

    async void Next_Click(object s, RoutedEventArgs e)
    {
        if (_installing) return;
        if (_page == 0) { if (AgreeCheck.IsChecked == true) GoPage(1); return; }
        if (_page == 1) { await InstallAsync(); return; }
        if (_page == 3) Finish();
    }

    async Task InstallAsync()
    {
        var target = FolderBox.Text.Trim();
        var exe = Path.Combine(target, "Moku.exe");
        try
        {
            _installing = true; GoPage(2);
            StatusText.Text = T("ШАГ 1 ИЗ 3  ·  ЗАКРЫВАЮ СТАРУЮ КОПИЮ", "STEP 1 OF 3  ·  STOPPING OLD COPY");
            // старая копия, висящая в фоне, блокировала файл и не давала острову показаться
            foreach (var pr in Process.GetProcessesByName("Moku")) { try { pr.Kill(true); pr.WaitForExit(4000); } catch { } }
            StatusText.Text = T("ШАГ 2 ИЗ 3  ·  КОПИРУЮ ФАЙЛЫ", "STEP 2 OF 3  ·  COPYING FILES");
            await Task.Run(() =>
            {
                Directory.CreateDirectory(target);
                using var src = Assembly.GetExecutingAssembly().GetManifestResourceStream("MokuInstaller.Payload.Moku.exe")
                    ?? throw new InvalidOperationException("Payload missing");
                FileStream? output = null;
                for (int a = 0; a < 6 && output == null; a++)
                {
                    try { output = new FileStream(exe, FileMode.Create, FileAccess.Write, FileShare.None); }
                    catch (IOException) when (a < 5) { Thread.Sleep(400); }
                }
                using (output!)
                {
                    var buf = new byte[1 << 16]; long total = src.Length, done = 0; int n;
                    while ((n = src.Read(buf, 0, buf.Length)) > 0)
                    {
                        output.Write(buf, 0, n); done += n;
                        int pct = (int)(done * 80 / Math.Max(1, total));
                        Dispatcher.Invoke(() => Progress.Value = pct);
                    }
                    output.Flush(true);
                }
                if (new FileInfo(exe).Length < 1024 * 1024) throw new InvalidOperationException("Incomplete file");
            });
            StatusText.Text = T("ШАГ 3 ИЗ 3  ·  ЯРЛЫКИ И НАСТРОЙКИ", "STEP 3 OF 3  ·  SHORTCUTS & SETTINGS");
            SetAnchor(StatusText); Progress.Value = 88;
            var startMenu = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs", "Moku");
            Directory.CreateDirectory(startMenu);
            CreateShortcut(Path.Combine(startMenu, "Moku.lnk"), exe);
            if (DesktopCheck.IsChecked == true) CreateShortcut(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "Moku.lnk"), exe);
            try
            {
                using var run = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run");
                if (AutoCheck.IsChecked == true) run.SetValue("Moku", "\"" + exe + "\""); else run.DeleteValue("Moku", false);
            }
            catch { }
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Moku");
            Directory.CreateDirectory(dir);
            var sp = Path.Combine(dir, "settings.json");
            var settings = new Dictionary<string, object>();
            if (File.Exists(sp)) { try { settings = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, object>>(File.ReadAllText(sp)) ?? new(); } catch { settings = new(); } }
            settings["Language"] = _en ? "en" : "ru";
            File.WriteAllText(sp, System.Text.Json.JsonSerializer.Serialize(settings, new System.Text.Json.JsonSerializerOptions { WriteIndented = true }));
            Progress.Value = 100; _installing = false; _done = true;
            GoPage(3);
        }
        catch (Exception ex)
        {
            _installing = false; GoPage(1);
            System.Windows.MessageBox.Show(this, T("Не удалось установить: ", "Install failed: ") + ex.Message, "Moku", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    void Finish()
    {
        try
        {
            var exe = Path.Combine(FolderBox.Text.Trim(), "Moku.exe");
            if (LaunchCheck.IsChecked == true && File.Exists(exe))
                Process.Start(new ProcessStartInfo(exe) { UseShellExecute = true, WorkingDirectory = Path.GetDirectoryName(exe)! });
        }
        catch (Exception ex) { System.Windows.MessageBox.Show(this, ex.Message, "Moku"); }
        Close();
    }

    static void CreateShortcut(string path, string target)
    {
        var t = Type.GetTypeFromProgID("WScript.Shell") ?? throw new InvalidOperationException("WSH unavailable");
        dynamic shell = Activator.CreateInstance(t)!;
        dynamic sc = shell.CreateShortcut(path);
        sc.TargetPath = target; sc.WorkingDirectory = Path.GetDirectoryName(target); sc.IconLocation = target + ",0"; sc.Description = "Moku"; sc.Save();
    }
}
